package com.sample2;

public class GamingLaptop extends Laptop {
	private int camRes;
	
	public GamingLaptop() {
	}
	
	public GamingLaptop(String brand, double size, String processor, String gpu, String memory, int camRes) {
	super(brand, size, processor, gpu, memory);
	this.camRes = camRes;
	}
	
	public void setCamRes(int camRes) {
		this.camRes = camRes;
	}
	public int getCamRes() {
		return this.camRes;
	}
		
	public void streamingUp(String adjective) {
		System.out.println("Ashley is playing and streaming " + adjective + "...");
	}
}
