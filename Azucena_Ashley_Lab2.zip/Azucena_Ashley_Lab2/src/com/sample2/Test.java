package com.sample2;

public class Test {

	public static void main(String[] args) {
		
		Laptop l1 = new Laptop();
		
		System.out.println("A laptop has been created...");
		l1.setBrand("Lenovo");
		l1.setGpu("RTX 2050");
		l1.setMemory("8GB");
		l1.setProcessor("i7-9thGen");
		l1.setSize(15.6);
		
	
		System.out.println("Brand: " + l1.getBrand ());
		System.out.println("GPU: " + l1.getGpu());
		System.out.println("Memory: " + l1.getProcessor());
		System.out.println("Processor: " + l1.getSize());
		System.out.println("Size: " + l1.getMemory());
		l1.Playing("real gamer");
		
		System.out.println(" ");
		
		GamingLaptop gl1 = new GamingLaptop();
		gl1.setBrand("Legion");
		gl1.setCamRes(128);
		gl1.setGpu("RTX 2080TI");
		gl1.setMemory("32GB");
		gl1.setProcessor("i9-7thGen");
		gl1.setSize(18.2);
		System.out.println("Brand: " + gl1.getBrand());
		System.out.println("Camera Resoulution: " + gl1.getCamRes());
		System.out.println("GPU: " + gl1.getGpu());
		System.out.println("Processor: " + gl1.getProcessor());
		System.out.println("Size: " + gl1.getSize());
		System.out.println("Memory: " + gl1.getMemory());
		gl1.streamingUp("like a pro and hardcore gamer");
		
		l1 = gl1;
	}
	

}
